# Contributor Covenant Code of Conduct

## Our Pledge

We as members, contributors, and leaders pledge to make participation in our
community a harassment-free experience for everyone, regardless of age, body
size, visible or invisible disability, ethnicity, sex characteristics, gender
identity and expression, level of experience, education, socio-economic status,
nationality, personal appearance, race, religion, or sexual identity and
orientation.

We pledge to act and interact in ways that contribute to an open, welcoming,
diverse, inclusive, and healthy community.

## Our Standards

Examples of behavior that contributes to a positive environment include:

- Demonstrating empathy and kindness toward other people.
- Being respectful of differing opinions, viewpoints, and experiences.
- Giving and gracefully accepting constructive feedback.
- Accepting responsibility and apologizing to those affected by our mistakes.
- Focusing on what is best for the community and project.

Examples of unacceptable behavior include:

- The use of sexualized language or imagery, and sexual attention or advances
  of any kind.
- Trolling, insulting or derogatory comments, and personal or political attacks.
- Public or private harassment.
- Publishing others' private information, such as a physical or email address,
  without their explicit permission.
- Other conduct which could reasonably be considered inappropriate in a
  professional setting.

## Enforcement Responsibilities

Project maintainers are responsible for clarifying and enforcing these
standards and will take appropriate and fair corrective action in response to
behavior they deem inappropriate, threatening, offensive, or harmful.

Maintainers have the right and responsibility to remove, edit, or reject
comments, commits, code, wiki edits, issues, and other contributions that are
not aligned with this Code of Conduct, and will communicate reasons for
moderation decisions when appropriate.

## Scope

This Code of Conduct applies within project spaces and when an individual is
officially representing the project in public spaces. Examples include using an
official project email address, posting through an official social media
account, or acting as an appointed representative at an online or offline
event.

## Enforcement

Instances of abusive, harassing, or otherwise unacceptable behavior may be
reported privately to the repository owner through the
[GitHub profile contact options](https://github.com/lsh235). Do not use a public
issue for sensitive reports. All complaints will be reviewed and investigated
promptly and fairly.

All project maintainers are obligated to respect the privacy and security of
the reporter of any incident.

## Attribution

This Code of Conduct is adapted from the
[Contributor Covenant](https://www.contributor-covenant.org), version 2.1,
available at https://www.contributor-covenant.org/version/2/1/code_of_conduct.html.
